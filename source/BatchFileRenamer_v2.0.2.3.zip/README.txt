#######################
#  Batch-FileRenamer  #
#######################
Version: 2.0.2.3
Author: Jonathan Riedmair (www.xcy7e.de)
Download: https://github.com/xcy7e/Batch-FileRenamer

---------------------------------------------------------
Description:
Rename multiple files or directories at once
apply filters & perform automatic numbering
revert your rename action
---------------------------------------------------------

Features:
- English, German & French interface language!
- Handles files & diretories!
- Revert your action - ter renaming
- Files can be limited by one or multiple filetypes!
- Clever & intuitive rule system:
- numbering (with optional leading zeros)
- replacing strings
- preview of applied rules
- Windows Explorer context menu integration (enable in settings)
- See your changes colorized in a handy item list
- Extremely intuitive UI
- Will be free & open source forever!

---------------------------------------------------------

##########################
#  INSTALL INSTRUCTIONS  #
##########################

> Extract archive and run SETUP.exe